import pygame
import random
import time

# Pygame initialization
pygame.init()
screen = pygame.display.set_mode((1920, 1080))
pygame.display.set_caption("Pac-Man")

pygame.mixer.init()
pygame.mixer.music.load("background.mp3")
pygame.mixer.music.play(-1)  # Loop music

# Color definitions
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
PINK = (255, 192, 203)  # Define pink color

# Global variables
difficulty = "EASY"
game_over = False
start_time = 0
total_time = 0
speed_boost = False
speed_boost_timer = 0
volume = 0.5
pygame.mixer.music.set_volume(volume)
scroll_offset = 0  # Scroll offset for documentation
maze_width = 48  # Width of the maze in cells
maze_height = 27  # Height of the maze in cells
cell_size = 40  # Size of each cell in pixels

# Fonts
font_large = pygame.font.Font(None, 50)
font_medium = pygame.font.Font(None, 38)
font_small = pygame.font.Font(None, 26)

# Directions for maze generation and movement
DIRECTIONS = [(0, -1), (1, 0), (0, 1), (-1, 0)]

def create_maze(width, height):
    def is_within_bounds(x, y):
        return 0 <= x < width and 0 <= y < height

    maze = [[0 for _ in range(width)] for _ in range(height)]
    stack = [(random.randint(0, width - 1), random.randint(0, height - 1))]
    while stack:
        cx, cy = stack[-1]
        maze[cy][cx] = 1
        directions = [(dx, dy) for dx, dy in DIRECTIONS]
        random.shuffle(directions)
        for dx, dy in directions:
            nx, ny = cx + dx * 2, cy + dy * 2
            if is_within_bounds(nx, ny) and maze[ny][nx] == 0:
                maze[cy + dy][cx + dx] = 1
                maze[ny][nx] = 1
                stack.append((nx, ny))
                break
        else:
            stack.pop()
    return maze

def draw_maze(maze, color):
    for y, row in enumerate(maze):
        for x, cell in enumerate(row):
            if cell == 0:
                pygame.draw.rect(screen, color, pygame.Rect(x * cell_size, y * cell_size, cell_size, cell_size))

def rgb_cycle():
    current_time = pygame.time.get_ticks()
    cycle_time = 3000  # 3 seconds for a full cycle
    phase = (current_time % cycle_time) / cycle_time

    if phase < 1/3:
        r = int(255 * (1 - phase * 3))
        g = int(255 * (phase * 3))
        b = 0
    elif phase < 2/3:
        r = 0
        g = int(255 * (1 - (phase - 1/3) * 3))
        b = int(255 * ((phase - 1/3) * 3))
    else:
        r = int(255 * ((phase - 2/3) * 3))
        g = 0
        b = int(255 * (1 - (phase - 2/3) * 3))
   
    return (r, g, b)

maze = create_maze(maze_width, maze_height)

def find_empty_cell(maze):
    while True:
        x = random.randint(0, maze_width - 1)
        y = random.randint(0, maze_height - 1)
        if maze[y][x] == 1:  # Empty cell
            return x * cell_size, y * cell_size

# Pac-Man class
class PacMan:
    def __init__(self):
        self.image = pygame.image.load("pacman.png")
        self.image = pygame.transform.scale(self.image, (40, 40))  # Resize Pac-Man
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = find_empty_cell(maze)
        self.speed = 5
        self.default_speed = 5

    def move(self, direction, maze):
        if direction == "LEFT" and not self.is_colliding(self.rect.x - self.speed, self.rect.y, maze):
            self.rect.x -= self.speed
        elif direction == "RIGHT" and not self.is_colliding(self.rect.x + self.speed, self.rect.y, maze):
            self.rect.x += self.speed
        elif direction == "UP" and not self.is_colliding(self.rect.x, self.rect.y - self.speed, maze):
            self.rect.y -= self.speed
        elif direction == "DOWN" and not self.is_colliding(self.rect.x, self.rect.y + self.speed, maze):
            self.rect.y += self.speed

    def is_colliding(self, x, y, maze):
        test_rect = self.rect.copy()
        test_rect.x = x
        test_rect.y = y
        for row in range(maze_height):
            for col in range(maze_width):
                if maze[row][col] == 0:  # Wall
                    wall_rect = pygame.Rect(col * cell_size, row * cell_size, cell_size, cell_size)
                    if test_rect.colliderect(wall_rect):
                        return True
        return False

    def draw(self):
        screen.blit(self.image, self.rect.topleft)

# Ghost class
class Ghost:
    def __init__(self, color, image_path):
        self.image = pygame.image.load(image_path)
        self.image = pygame.transform.scale(self.image, (30, 30))  # Resize ghost
        self.color = color
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = find_empty_cell(maze)
        self.speed = {"EASY": 2, "MEDIUM": 4, "HARD": 6}[difficulty]
        self.target = None

    def move(self, maze, pacman_rect=None):
        if self.color == RED and pacman_rect:
            # Move towards Pac-Man
            if self.rect.x < pacman_rect.x and not self.is_colliding(self.rect.x + self.speed, self.rect.y, maze):
                self.rect.x += self.speed
            elif self.rect.x > pacman_rect.x and not self.is_colliding(self.rect.x - self.speed, self.rect.y, maze):
                self.rect.x -= self.speed
            if self.rect.y < pacman_rect.y and not self.is_colliding(self.rect.x, self.rect.y + self.speed, maze):
                self.rect.y += self.speed
            elif self.rect.y > pacman_rect.y and not self.is_colliding(self.rect.x, self.rect.y - self.speed, maze):
                self.rect.y -= self.speed
        else:
            # Random movement for other ghosts
            if not self.target or (self.rect.x == self.target[0] and self.rect.y == self.target[1]):
                self.target = find_empty_cell(maze)
            if self.rect.x < self.target[0] and not self.is_colliding(self.rect.x + self.speed, self.rect.y, maze):
                self.rect.x += self.speed
            elif self.rect.x > self.target[0] and not self.is_colliding(self.rect.x - self.speed, self.rect.y, maze):
                self.rect.x -= self.speed
            if self.rect.y < self.target[1] and not self.is_colliding(self.rect.x, self.rect.y + self.speed, maze):
                self.rect.y += self.speed
            elif self.rect.y > self.target[1] and not self.is_colliding(self.rect.x, self.rect.y - self.speed, maze):
                self.rect.y -= self.speed

    def is_colliding(self, x, y, maze):
        test_rect = self.rect.copy()
        test_rect.x = x
        test_rect.y = y
        for row in range(maze_height):
            for col in range(maze_width):
                if maze[row][col] == 0:  # Wall
                    wall_rect = pygame.Rect(col * cell_size, row * cell_size, cell_size, cell_size)
                    if test_rect.colliderect(wall_rect):
                        return True
        return False

    def draw(self):
        screen.blit(self.image, self.rect.topleft)

# Bonus class
class Bonus:
    def __init__(self):
        self.image = pygame.image.load("bonus.png")
        self.image = pygame.transform.scale(self.image, (20, 20))  # Resize bonus
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = find_empty_cell(maze)

    def draw(self):
        screen.blit(self.image, self.rect.topleft)

# Score class
class Score:
    def __init__(self):
        self.score = 0
        self.font = pygame.font.Font(None, 36)

    def increase(self, amount):
        self.score += amount

    def draw(self):
        score_text = self.font.render(f"Score: {self.score}", True, WHITE)
        screen.blit(score_text, (10, 10))

# Special functions
def special_teleport(pacman):
    if pacman.rect.x > 1920:
        pacman.rect.x = 0
    elif pacman.rect.x < 0:
        pacman.rect.x = 1920
    if pacman.rect.y > 1080:
        pacman.rect.y = 0
    elif pacman.rect.y < 0:
        pacman.rect.y = 1080

def handle_collision(pacman, ghosts, score):
    global speed_boost, speed_boost_timer
    for ghost in ghosts:
        if pacman.rect.colliderect(ghost.rect):
            if ghost.color == GREEN:
                ghosts.remove(ghost)
                score.increase(10)
            elif ghost.color == BLUE:
                ghosts.remove(ghost)
                speed_boost = True
                speed_boost_timer = pygame.time.get_ticks()
                pacman.speed = 10
            else:
                return False  # Game over if touching a non-green ghost
    return True

def check_bonus(pacman, bonus, score):
    if pacman.rect.colliderect(bonus.rect):
        score.increase(50)
        bonus.rect.x, bonus.rect.y = find_empty_cell(maze)

def add_random_ghost(ghosts):
    if random.randint(1, 100) <= {"EASY": 1, "MEDIUM": 3, "HARD": 5}[difficulty]:  # Probability
        color_choice = random.choices([RED, GREEN, BLUE], weights=[1, 3, 3])[0]
        image_path = {
            RED: "ghost_red.png",
            GREEN: "ghost_green.png",
            BLUE: "ghost_blue.png"
        }[color_choice]
        new_ghost = Ghost(color_choice, image_path)
        ghosts.append(new_ghost)

def shield_powerup(pacman, shield_active):
    if shield_active:
        pygame.draw.circle(screen, BLUE, pacman.rect.center, 40, 3)

def draw_timer(start_time):
    elapsed_time = int(time.time() - start_time)
    timer_text = font_small.render(f"Time: {elapsed_time}s", True, WHITE)
    screen.blit(timer_text, (1700, 10))
    return elapsed_time

def draw_ghost_info():
    info_text = [
        ("Red Ghost: Follows you", RED),
        ("Green Ghost: Gives points", GREEN),
        ("Blue Ghost: Gives speed boost", BLUE)
    ]
    y_start = 400
    for text, color in info_text:
        ghost_text = font_small.render(text, True, color)
        screen.blit(ghost_text, (50, y_start))
        y_start += 40

# Loading screen
def show_loading_screen():
    screen.fill(BLACK)
    loading_text = font_large.render("Loading...", True, WHITE)
    screen.blit(loading_text, (860, 540))
    pygame.display.flip()
    time.sleep(2)

# Title screen
def show_title_screen():
    title_active = True
    while title_active:
        screen.fill(BLACK)
        title_text = font_large.render("Pac-Man Enhanced", True, PINK)
        start_text = font_medium.render("Press Enter to Start", True, WHITE)
        screen.blit(title_text, (740, 300))
        screen.blit(start_text, (780, 500))
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    title_active = False

# Main menu screen
def show_main_menu():
    global difficulty
    menu_active = True
    while menu_active:
        screen.fill(BLACK)
        title_text = font_large.render("Select Difficulty", True, PINK)
        easy_text = font_medium.render("Easy", True, WHITE)
        medium_text = font_medium.render("Medium", True, WHITE)
        hard_text = font_medium.render("Hard", True, WHITE)

        screen.blit(title_text, (740, 300))
        screen.blit(easy_text, (840, 400))
        screen.blit(medium_text, (840, 500))
        screen.blit(hard_text, (840, 600))

        pygame.display.flip()

        mouse_pos = pygame.mouse.get_pos()
        mouse_click = pygame.mouse.get_pressed()
        if mouse_click[0]:
            if 840 <= mouse_pos[0] <= 1040 and 400 <= mouse_pos[1] <= 450:
                difficulty = "EASY"
                menu_active = False
            elif 840 <= mouse_pos[0] <= 1040 and 500 <= mouse_pos[1] <= 550:
                difficulty = "MEDIUM"
                menu_active = False
            elif 840 <= mouse_pos[0] <= 1040 and 600 <= mouse_pos[1] <= 650:
                difficulty = "HARD"
                menu_active = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

# Game over screen
def show_game_over_screen(score, elapsed_time):
    global game_over
    screen.fill(BLACK)
    game_over_text = font_large.render("Game Over", True, RED)
    score_text = font_medium.render(f"Score: {score.score}", True, WHITE)
    time_text = font_medium.render(f"Time: {elapsed_time}s", True, WHITE)
    return_text = font_small.render("Press R to return to the main menu or Q to quit", True, WHITE)
    screen.blit(game_over_text, (800, 400))
    screen.blit(score_text, (880, 500))
    screen.blit(time_text, (880, 550))
    screen.blit(return_text, (620, 650))
    pygame.display.flip()

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_r:
                    game_over = True
                    return
                elif event.key == pygame.K_q:
                    pygame.quit()
                    exit()

# Game setup
def game_setup():
    global start_time, game_over
    start_time = time.time()
    game_over = False

# Main game loop
def main_game_loop():
    global game_over, total_time, speed_boost, speed_boost_timer
    pacman = PacMan()
    ghosts = [Ghost(RED, "ghost_red.png"), Ghost(GREEN, "ghost_green.png")]
    bonus = Bonus()
    score = Score()
    clock = pygame.time.Clock()
    shield_active = False
    shield_timer = 0

    running = True
    red_ghost_speed_increment_time = pygame.time.get_ticks()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_LEFT]:
            pacman.move("LEFT", maze)
        if keys[pygame.K_RIGHT]:
            pacman.move("RIGHT", maze)
        if keys[pygame.K_UP]:
            pacman.move("UP", maze)
        if keys[pygame.K_DOWN]:
            pacman.move("DOWN", maze)
        if keys[pygame.K_SPACE] and not shield_active:
            shield_active = True
            shield_timer = pygame.time.get_ticks()

        # Speed boost timing
        if speed_boost and pygame.time.get_ticks() - speed_boost_timer > 5000:
            speed_boost = False
            pacman.speed = pacman.default_speed

        # Red ghost speed increment every 30 seconds
        current_time = pygame.time.get_ticks()
        if current_time - red_ghost_speed_increment_time >= 30000:
            for ghost in ghosts:
                if ghost.color == RED:
                    ghost.speed += 1
            red_ghost_speed_increment_time = current_time

        screen.fill(BLACK)
        wall_color = rgb_cycle()
        draw_maze(maze, wall_color)
        pacman.draw()
        bonus.draw()
        score.draw()
        draw_ghost_info()

        for ghost in ghosts:
            ghost.move(maze, pacman.rect if ghost.color == RED else None)
            ghost.draw()

        special_teleport(pacman)
        running = handle_collision(pacman, ghosts, score)
        check_bonus(pacman, bonus, score)
        add_random_ghost(ghosts)
        shield_powerup(pacman, shield_active)

        total_time = draw_timer(start_time)
        pygame.display.flip()
        clock.tick(60)

    show_game_over_screen(score, total_time)

# Main function
def main():
    show_loading_screen()
    show_title_screen()
    while True:
        show_main_menu()
        game_setup()
        main_game_loop()

if __name__ == "__main__":
    main()